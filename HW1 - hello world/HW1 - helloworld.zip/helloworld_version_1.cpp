#include <iostream>

int main() { //initialize the main function
    std::cout  << "Hello, world!" << std::endl; 
}
