#include <iostream> 

using namespace std; 

int main() { //initialize the main function
    cout  << "Hello, world!" << endl; 
}
