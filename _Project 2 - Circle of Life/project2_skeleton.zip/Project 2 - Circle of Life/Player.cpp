#include "Player.h"

Player::Player(){
    //min values for each
    _name = "";
    _age = MIN_AGE;
    _agility = MIN_STAT;
    _mana = MIN_STAT;
    _wisdom = MIN_STAT;
    _sardines = 0;
}
Player::Player(std::string name, int agility, int mana, int wisdom){
    _age = MIN_AGE;
    _sardines = 0;
    _name = name;

    if (!isValid(agility)) {
        _agility = MIN_STAT;
    } else {
        _agility = agility;  
    }

    if (!isValid(mana)) {
        _mana = MIN_STAT;
    } else {
        _mana = mana;  
    }

    if (!isValid(wisdom)) {
        _wisdom = MIN_STAT;
    } else {
        _wisdom = wisdom;  
    }
}
bool Player::setName(std::string name){
    //checks that the name is only letters
    for (char c : name) {
        if (tolower(c) < 97 || tolower(c) > 172) {
            std::cout << "Invalid name. Please try again." << std::endl;
            return false;
        }
    }
    _name = name;
    return true;
}
bool Player::setAgility(int agility){
    if (!isValid(agility)) {
        std::cout << "Unable to set agility with value: " << agility << std::endl;
        return false;
    } 
    
     _agility = agility;
     return true;
}
bool Player::setMana(int mana){
    if (!isValid(mana)) {
        std::cout << "Unable to set mana with value: " << mana << std::endl;
        return false;
    } 
    
     _mana = mana;
     return true;
}
bool Player::setWisdom(int wisdom){
    if (!isValid(wisdom)) {
        std::cout << "Unable to set wisdom with value: " << wisdom << std::endl;
        return false;
    } 
    
     _wisdom = wisdom;
     return true;
}
bool Player::setSardines(int sardines){
    //not sure on valid inputs for this yet, may have to add input validation later
    _sardines = sardines;
    return true;
}
bool Player::setAge(int age){
    if (age < MIN_AGE || age > MAX_AGE) {
        std::cout << "Unable to set age with value: " << age << std::endl;
        return false;
    } 
    
     _age = age;
     return true;
}
void Player::setfamiliar(std::string familiar){
    familiar = _familiar;
}
bool Player::setPlayerAge(std::string player_name){
    //checks that the name is only letters
    for (char c : player_name) {
        if (tolower(c) < 97 || tolower(c) > 172) {
            std::cout << "Invalid player name. Please try again." << std::endl;
            return false;
        }
    }
    _player_name = player_name;
    return true;
}
void Player::magicSchool(){
    //add validation to make sure stats dont go over the max
    _agility += 500;
    _mana += 500;
    _wisdom += 1000;
    _sardines -= 5000;
    //choosefamiliar
    //set position to first path
}
void Player::toDungeon(){
    //add validation to make sure stats dont go over the max
    _sardines += 5000;
    _agility += 200;
    _wisdom += 200;
    _mana += 200;
    //set position to second path

}
void Player::printStats(){
    std::cout << _name << ", age " << _age << std::endl
    << "Agility: " << _agility << std::endl 
    << "Mana: " << _mana << std::endl 
    << "Wisdom: " << _wisdom << std::endl 
    << "Sardines: " << _sardines << std::endl;
}