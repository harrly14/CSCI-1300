#include <iostream>
#ifndef PLAYER_H
#define PLAYER_H

class Player {
    private:
        const int MAX_STAT = 1000;
        const int MIN_STAT = 100;
        const int MAX_AGE = 20;
        const int MIN_AGE = 1;

        std::string _name;
        int _agility, _mana, _wisdom, _sardines, _age;
        std::string _familiar, _player_name;

        bool isValid(int stat) const {
            return stat <= MAX_STAT && stat >= MIN_STAT;
        }
    public:
        Player();
        Player(std::string name, int agility, int mana, int wisdom);

        std::string getName() const {return _name;}
        int getStrength() const {return _agility;}
        int getStamina() const {return _mana;}
        int getWisdom() const {return _wisdom;}
        int getPridePoints() const {return _sardines;}
        int getAge() const {return _age;}
        std::string getPlayerName() const {return _player_name;}

        bool setName(std::string name);
        bool setAgility(int agility);
        bool setMana(int mana);
        bool setWisdom(int wisdom);
        bool setSardines(int sardines);
        bool setAge(int age);
        void setfamiliar(std::string familiar);
        bool setPlayerAge(std::string player_name);

        void magicSchool();
        void toDungeon();
        void printStats();
};

#endif