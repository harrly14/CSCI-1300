#include "player.h"
#include "Board.h"

//void choosefamiliar (player.familiar)
    //display prompt
    //display menu of familiars (based on what familiar they have)
    //depending on familiar selection, update player.familiar
//selectcharacter

//display main menu (takes an input of 1-5. if -1, show whole main menu. 1-5, show submenu for each option)
        //if input 1, show print player's stats
            //option to move stats to sardines (or refactor)
        //if input 2, show character's name and age
            //option to add a cool wizard's name
        //if input 3, display board
        //if input 4, display current familiar
            //option to display familiar's ability and select which familiar you want
        //if input 5, movePlayer() a rand amount (1-6)
        //else, print invalid input
//winning sequence
    //for each player
        //for each stat (other than sardines and age)
            //increment sardines for every 100 in each stat
        
    //if p1 sardines > p2 sardines
        //congrats p1
    //else if p2 sardines > p1 sardines 
        //congrats p2
    //else if p1 sardines == p2 sardines
        //its a tie. you both lose

    //for each player
        //display stats

int main() {
    //seed random number generator
    srand(time(0));

    //create a board object
    //initialize the board with no one on it
    //display board
    Board game_board = Board();
    game_board.displayBoard();
    
    Player player1 = Player();

    //create players array (size num_of_players) 
    //for loop num_of_players times
        //add player to player_num in board
        //set player i _player_name to the name they input
        //selectCharacter(player_num)
            //displays available characters
            //has the player select a character
            //says success! and prints stats
    
        //prompt player i to choose path [magic school or to dungeon]
        //if magic school
            //player.magicSchool();
        //else if dungeon
            //player.toDungeon();

    //display board (updated with positions)

    //while neither player position is the last tile or greater
        //for each player
            //display main menu(-1)
            //wait for user input
            //display main menu (user input)
        
            //after moved
            //evaluate current tile conditions
               //if tile is the end, give a finishing first bonus, and end the loop
            //prompt if they want to do anything else or end the turn

    //winning sequence

    return 0;
}