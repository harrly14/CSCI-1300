#include "Board.h"
#include <iostream>
#define RED "\033[48;2;230;10;10m"
#define GREEN "\033[48;2;34;139;34m"  /* Grassy Green (34,139,34) */
#define BLUE "\033[48;2;10;10;230m"
#define PINK "\033[48;2;255;105;180m"
#define BROWN "\033[48;2;139;69;19m"
#define PURPLE "\033[48;2;128;0;128m"
#define ORANGE "\033[48;2;230;115;0m" /* Orange (230,115,0) */
#define GREY "\033[48;2;128;128;128m" /* Grey (128,128,128) */
#define RESET "\033[0m"

void Board::initializeBoard()
{
    // Seed random number generator in your main function once
    for (int i = 0; i < 2; i++)
    {
        initializeTiles(i);  // This ensures each lane has a unique tile distribution
    }
}

#include <cstdlib> // For rand() and srand()
#include <ctime>   // For time()

void Board::initializeTiles(int player_index)
{
    Tile temp;
    int green_count = 0;
    int total_tiles = _BOARD_SIZE;


    // Keep track of green tile positions to ensure we place exactly 30 greens
    for (int i = 0; i < total_tiles; i++)
    {
        if (i == 25) {
            //second half odds may be different
            setOdds(player_index, 2);
        }

        if (i == total_tiles - 1) {
            // Set the last tile as Orange for "Pride Rock"
            temp.color = 'O';
            temp.type = "End";
        } 
        else if (i == 0) {
            // Set the first tile as Grey for Starting Point
            temp.color = 'Y';
            temp.type = "Start";
            setOdds(player_index, 1);
        } 
        //doesn't necessarily always get the max number of green tiles
        else if (green_count < _max_green_tiles && (rand() % (total_tiles - i) < _max_green_tiles - green_count)) {
            temp.color = 'G';
            temp.type = "Normal";
            green_count++;
        }
        else
        {
            //added logic: special tiles of the same type cannot repeat twice in a row
            char previous_tile_color = _tiles[player_index][i-1].color;
            do {
                int color_choice = rand() % 100;

                //Blue = B, Pink = P, Brown = N, Red= R, Purple =U
                if ((color_choice>= 0 && color_choice < _graveyard_odds)) {
                    temp.color = 'R';
                    temp.type = "Graveyard";
                } else if ((color_choice >= _graveyard_odds && color_choice < _hyena_odds)){
                    temp.color = 'N';
                    temp.type = "Hyena";
                } else if ((color_choice >= _hyena_odds && color_choice < _pet_odds)){
                    temp.color = 'P';
                    temp.type = "Pet";
                } else if ((color_choice >= _pet_odds && color_choice < _oasis_odds)){
                    temp.color = 'B';
                    temp.type = "Oasis";
                } else if (color_choice >= _oasis_odds) {
                    temp.color = 'U';
                    temp.type = "Challenge";
                }
            } 
            while (temp.color == previous_tile_color);
        }


        // Assign the tile to the board for the specified lane
        _tiles[player_index][i] = temp;
    }
}

void Board::setOdds(int player_index, int half) {
    if (half != 1 && half !=2) {
        std::cout << "Invalid half. Cannot set odds." << std::endl;
        return;
    }

    //0 = magic school
    if (player_index == 0) {
        _max_green_tiles = 30;
        _graveyard_odds = 20;
        _hyena_odds = 20 + _graveyard_odds;
        _pet_odds = _hyena_odds + 15;

        if (half == 1){
            _oasis_odds = _pet_odds + 25;
        } else if (half == 2) {
            _oasis_odds = 15;
        }
    } else if (player_index == 1) {
        _max_green_tiles = 20;
        if (half == 1){
            _graveyard_odds = 25;
            _hyena_odds = _graveyard_odds + 25;
            _pet_odds = _hyena_odds + 20;
            _oasis_odds = _pet_odds + 5;

        } else if (half == 2) {
            _graveyard_odds = 15;
            _hyena_odds = _graveyard_odds + 15;
            _pet_odds = _hyena_odds + 20;
            _oasis_odds = _pet_odds + 25;
        }
    }
}

Board::Board()
 {
    //will be used for pre-game loading the board without players on it
     _player_count = 0;

     // Initialize player position
     //_player_position[0] = 0;

     // Initialize tiles
     initializeBoard();
 }

Board::Board(int player_count)
{
    if (player_count > _MAX_PLAYERS)
    {
        _player_count = _MAX_PLAYERS;
    }
    else
    {
        _player_count = player_count;
    }

    // Initialize player position
    for (int i = 0; i < _player_count; i++)
    {
        _player_position[i] = 0;
        _player_board[i] = i;

    }

    // Initialize tiles

    initializeBoard();
}

bool Board::isPlayerOnTile(int player_index, int board_num, int pos)
{
    if (_player_position[player_index] == pos && _player_board[player_index] == board_num)
    {
        return true;
    }
    return false;
}

void Board::displayTile(int player_index, int board_num, int pos)
{
    // string space = "                                       ";
    std::string color = "";

    // Template for displaying a tile: <line filler space> <color start> |<player symbol or blank space>| <reset color> <line filler space> <endl>

    // Determine color to display
    if (_tiles[player_index][pos].color == 'R')
    {
        color = RED;
    }
    else if (_tiles[player_index][pos].color == 'G')
    {
        color = GREEN;
    }
    else if (_tiles[player_index][pos].color == 'B')
    {
        color = BLUE;
    }
    else if (_tiles[player_index][pos].color == 'U')
    {
        color = PURPLE;
    }
    else if (_tiles[player_index][pos].color == 'N')
    {
        color = BROWN;
    }
    else if (_tiles[player_index][pos].color == 'P')
    {
        color = PINK;
    }
    else if (_tiles[player_index][pos].color == 'O')
    {
        color = ORANGE;
    }
    else if (_tiles[player_index][pos].color == 'Y')
    {
        color = GREY;
    }

    if (isPlayerOnTile(player_index, board_num, pos))
    {
        //does not scale for more than 2 players
        int other_player = 1;
        if (player_index == 1) {
            other_player = 0;
        }
        if (isPlayerOnTile(other_player, board_num, pos)){
            std::cout << color << "|1+2|" << RESET;
        } else {
            std::cout << color << "|" << (player_index + 1) << "|" << RESET;
        }

    }
    else
    {
        std::cout << color << "| |" << RESET;
    }
}

void Board::displayTrack(int player_index, int board_num)
{
    for (int i = 0; i < _BOARD_SIZE; i++)
    {
        displayTile(player_index, board_num, i);
    }
    std::cout << std::endl;
}

void Board::displayBoard()
{
    for (int i = 0; i < 2; i++)
    {
        if (i == 0) {
            std::cout << "Magic school: ";
        } else if (i == 1) {
            std::cout << "     Dungeon: ";
        }
        displayTrack(i, i);
        if (i == 0) {
            std::cout << std::endl;  // Add an extra line between the two lanes
        }
    }
}

bool Board::movePlayer(int player_index, int spaces_moved)
 {
     // Increment player position
     _player_position[player_index] += spaces_moved;
     if (_player_position[player_index] >= _BOARD_SIZE - 1)
     {
         // Player reached last tile
         _player_position[player_index] = 51;
         return true;
     }
     if (_player_position[player_index] < 1) {
        _player_position[player_index] = 1;
     }
     return false;
 }

 int Board::getPlayerPosition(int player_index) const
 {
     if (player_index >= 0 && player_index <= _player_count)
     {
         return _player_position[player_index];
     }
     return -1;
 }

void Board::setPlayerBoard(int player_num, int board_num) {
    if (board_num > 2 || board_num < 1) {
        std::cout << "Unable to set player's board. Make sure it is being set to a 1 or a 2." << std::endl;
        return;
    }
    _player_board[player_num - 1] = board_num - 1;
}

int Board::getPlayerBoard(int player_index) const {
     if (player_index >= 0 && player_index <= _player_count)
     {
         return _player_board[player_index];
     }
     return -1;
 }