#ifndef TILE_H
#define TILE_H
#include <string>

struct Tile {
    char color;
    std::string type;
};

#endif