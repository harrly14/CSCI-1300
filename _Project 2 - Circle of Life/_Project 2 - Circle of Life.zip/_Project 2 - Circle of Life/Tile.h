#ifndef TILE_H
#define TILE_H
#include <string>

struct Tile {
    char color;
    
};

#endif