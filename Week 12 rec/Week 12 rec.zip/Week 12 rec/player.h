#include <iostream>


class Player {
    private:
        std::string _name;
        int _strength, _stamina, _wisdom, _pride_points, _age;
    public:
        Player();
        Player(std::string name, int strength, int stamina, int wisdom);
        std::string getName();
        int getStrength();
        int getStamina();
        int getWisdom();
        int getPridePoints();
        int getAge();
        bool setName(std::string name);
        bool setStrength(int strength);
        bool setStamina(int stamina);
        bool setWisdom(int wisdom);
        bool setPridePoints(int pride_points);
        bool setAge(int age);
        void trainCub(int strength, int stamina, int wisdom);
        void toPrideLands();
        void printStats();
};