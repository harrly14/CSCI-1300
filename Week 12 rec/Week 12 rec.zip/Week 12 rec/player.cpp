#include "player.h"

Player::Player(){
    //min values for each
    _name = "";
    _age = 1;
    _strength = 100;
    _stamina = 100;
    _wisdom = 100;
    _pride_points = 0;
}
Player::Player(std::string name, int strength, int stamina, int wisdom){
    _age = 1;
    _pride_points = 0;
    _name = name;
    //sets attr to minimum if the inputted value is invalid
    if (strength > 1000 || strength < 100) {
        _strength = 100;
    } else {
        _strength = strength;  
    }
    if (stamina > 1000 || stamina < 100) {
        stamina = 100;
    } else {
        _stamina = stamina;  
    }
    if (wisdom > 1000 || wisdom < 100) {
        _wisdom = 100;
    } else {
        _wisdom = wisdom;  
    }
}
std::string Player::getName(){
    return _name;
}
int Player::getStrength(){
    return _strength;
}
int Player::getStamina(){
    return _stamina;
}
int Player::getWisdom(){
    return _wisdom;
}
int Player::getPridePoints(){
    return _pride_points;
}
int Player::getAge(){
    return _age;
}
bool Player::setName(std::string name){
    //checks that the name is only letters
    for (char c : name) {
        if (tolower(c) < 97 || tolower(c) > 172) {
            std::cout << "Invalid name. Please try again." << std::endl;
            return false;
        }
    }
    _name = name;
    return true;
}
bool Player::setStrength(int strength){
    if (strength > 1000 || strength < 100) {
        std::cout << "Unable to set strength with value: " << strength << std::endl;
        return false;
    } 
    
     _strength = strength;
     return true;
}
bool Player::setStamina(int stamina){
    if (stamina > 1000 || stamina < 100) {
        std::cout << "Unable to set stamina with value: " << stamina << std::endl;
        return false;
    } 
    
     _stamina = stamina;
     return true;
}
bool Player::setWisdom(int wisdom){
    if (wisdom > 1000 || wisdom < 100) {
        std::cout << "Unable to set wisdom with value: " << wisdom << std::endl;
        return false;
    } 
    
     _wisdom = wisdom;
     return true;
}
bool Player::setPridePoints(int pride_points){
    //not sure on valid inputs for this yet, may have to redefine later
    _pride_points = pride_points;
    return true;
}
bool Player::setAge(int age){
    if (age > 20 || age < 1) {
        std::cout << "Unable to set age with value: " << age << std::endl;
        return false;
    } 
    
     _age = age;
     return true;
}
void Player::trainCub(int strength, int stamina, int wisdom){
    //add input validation?
    _strength += strength;
    _stamina += stamina;
    _wisdom += wisdom;
    _pride_points -= 5000;
}
void Player::toPrideLands(){
    _pride_points += 5000;
    _strength -= 2000;
    _wisdom -= 2000;
    _stamina -=1000;
}
void Player::printStats(){
    std::cout << _name << ", age " << _age << std::endl
    << "Strength: " << _strength << std::endl 
    << "Stamina " << _stamina << std::endl 
    << "Wisdom: " << _wisdom << std::endl 
    << "Pride Points: " << _pride_points << std::endl;
}